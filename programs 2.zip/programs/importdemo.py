
import math
print(math.log(2))
print(math.floor(34.4))



