import csv
#windows: with open(".\\csvfiles\\adult.csv","r") as fobj:
#linux:  with open("./csvfiles/adult.csv","r") as fobj:
workdict = dict()
with open("./csvfiles/adult.csv","r") as fobj:
    data = csv.reader(fobj)
    #processing
    for line in data:
        if "?" not in line[1]:
            workclass = line[1].strip()
            workdict[workclass] = 1     #{"Private":1 ,"Local-gov":1, "Public":1}
    for key in workdict:
        print(key)




workset = set()
with open("./csvfiles/adult.csv","r") as fobj:
    header = fobj.readline()
    data = csv.reader(fobj)
    #processing
    for line in data:
        if "?" not in line[1]:
            workclass = line[1].strip()
            workset.add(workclass)    #{"Private":1 ,"Local-gov":1, "Public":1}
    for key in workset:
        print(key)
