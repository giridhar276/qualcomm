
import csv

try:
    with open("./csvfiles/adult.csv","r") as fobj:
        data = csv.reader(fobj)
        for line in data:
            print(line[1])
            print(line[3])
except FileNotFoundError as err:
    print("File is not found.. please check")
    print("System error :",err)
except TypeError as err:
    print("Invalid operation",err)
except ValueError as err:
    print("Invalid objects",err)
except (KeyError,IndexError) as err:
    print("Invalid index or key",err)
except Exception as err:
    print(err)

print("after exception handling")