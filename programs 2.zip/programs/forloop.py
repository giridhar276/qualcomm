# range(start,stop,step)  # default step value is 1
for val in range(1,11,):
    print(val)

name = 'python'       # iterating the string
for char in name:
    print(char)

alist = [10,20,30]    # iterating the list
for val in alist:
    print(val)

book  = { "chap1":10 ,"chap2":20 ,"chap3":30 }    # dictionary
for key in book.keys():
    print(key)

for key in book:   # displaying keys
    print(key)

for value in book.values():
    print(value)

for key,value in book.items():
    print(key,value)


aset = {10,10,20,30,20,20,30}
print(aset)
for value in aset:
    print(value)

print(type(name))
print(type(book))

print(isinstance(name,str))   #If type of name is str.. it returns True
print(isinstance(name,list))  #If type of name is not str.. it returns False

print(isinstance(book,dict))
print(isinstance(book,str))
