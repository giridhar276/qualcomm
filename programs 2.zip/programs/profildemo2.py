import time

def slow_function():
    time.sleep(1)
    return "Done"

def fast_function():
    return "Done"

def main():
    slow_function()
    fast_function()

main()