

import timeit

time_taken = timeit.timeit("sum(range(100))", number = 1000) #number specifies the no. o times code snippet is executed

print(time_taken)




from timeit import Timer

def demo():
    output = sum(range(100))

t = Timer(demo)

time_taken = t.timeit(number = 1000)
print("time taken :", time_taken)
