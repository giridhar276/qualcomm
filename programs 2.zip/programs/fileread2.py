import csv
with open("./csvfiles/adult.csv","r") as fobj:
    mcount = 0
    fcount = 0
    data = csv.reader(fobj)
    for line in data:
        gender = line[9].strip()  #will remove whitespaces at both the ends
        if gender == "Male":
            mcount = mcount + 1
        else:
            fcount = fcount + 1
    print("Total male count :",mcount)
    print("Total female count:",fcount)