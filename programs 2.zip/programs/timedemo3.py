


import timeit

setup_code = 'from math import sqrt'
test_code = 'sqrt(25)'

# Measure execution time with setup code
time_taken = timeit.timeit(test_code, setup=setup_code, number=1000)
print(f'Time taken: {time_taken} seconds')

