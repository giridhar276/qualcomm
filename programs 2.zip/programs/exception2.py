
import csv

try:
    fobj = open("./csvfiles/adult.csv")
except Exception as err:
    print(err)
else:
    for line in fobj:
        print(line)
finally:
    print("finally block will be executed all the times")

print("after exception handling")


'''
try
except
else ( optional)
finaly( optional)
'''