


aset = {10,20,20,10,10,20,30}
print(aset)
bset = {30,30,30,40,40,50}
print(bset)
print(aset.union(bset))

print(aset.intersection(bset))

print(aset.difference(bset))

aset.add(30)
print("After adding",aset)
aset.add(10)
print("After adding",aset)
aset.add(100)
print("After adding",aset)
print(aset.issuperset(bset))
print(aset.issubset(bset))