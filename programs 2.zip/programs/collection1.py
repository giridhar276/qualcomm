
import time

start = time.time()

from collections import defaultdict
grades = [('rita', 81), ('Bob', 90), ('rita', 82), ('Bob', 75), ('rita', 89)]
student_grades = defaultdict(list)
for name,grade in grades:
    student_grades[name].append(grade)
print(dict(student_grades))
print(student_grades["rao"])





from collections import Counter, OrderedDict
s = "abracadabra"
counter = Counter(s)
getcount = OrderedDict(counter.items())
print(dict(getcount))


import heapq
list1 = [1, 3, 5]
list2 = [2, 4, 6]
list3 = [0, 7, 8]


final_list = list(heapq.merge(list1,list2,list3))
print(final_list)
#write a program to read the above lists and display the sorted values in list.

import heapq
alist = [45,1,34,65,3,5,43,7,30,6,32,67,34,5]
#heapq.nsmallest(noofelements,alist)
smallest_values = heapq.nsmallest(3,alist)
print(smallest_values)
largest_values = heapq.nlargest(3,alist)
print(largest_values)



import heapq

nums = [7, 2, 5, 3, 9, 1, 6]
heapq.heapify(nums)  # Transform list into a heap
min_element = heapq.heappop(nums)  # Extract the minimum element
print(min_element)
print(nums)

stop = time.time()

print("Total time taken :", stop-start )