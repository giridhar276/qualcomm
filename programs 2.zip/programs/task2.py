import os
try:
    for file in os.listdir():
        print(file)
except Exception as err:
    print(err)


#write a program to display all the files from C: line by line
import os
try:
    for file in os.listdir("C:\\"):
        print(file)
except Exception as err:
    print(err)


#write a program to display ONLY .py files  from the current direcotory line by line

import os
try:
    for file in os.listdir():
        if file.endswith(".py"):
            print(file)
except Exception as err:
    print(err)


#write a progarm to delete .py files from the current directory

import os
try:
    for file in os.listdir():
        if file.endswith(".csv"):
            os.remove(file)
except Exception as err:
    print(err)

'''
write a program to create 100 directories in the below format


dir1
dir2
..
dir100
'''

'''
for idir in range(10):
    os.mkdir("dir" + str(idir))
'''


for idir in range(10):
    os.rmdir("dir" + str(idir))