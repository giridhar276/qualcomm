
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)


#lambda function
#inline function
#Instead of writing traditional function body, we define the lambda function
# lambda will be replaced in teh function call itself
# execution time is pretty fasted compared the regular appraoch
# lambda is the replacement of single liner function
#syntax:
#functioname = lambda variables: expression


display = lambda a,b : a + b
total = display(10,20)
print(total)


toupper = lambda a : a.upper() +" " + "programming".upper()
total = toupper('python')
print(total)


#traditional way
alist = [10,20,30,40,50]
blist = []
for val in alist:
    blist.append(val +5)



# 2nd method
#map(function,iterable)
alist = [10,20,30,40,50]
def increment(x):
    return x + 5
print(list(map(increment,alist)))

#
increment = lambda x: x+5
print(list(map(increment,alist)))


#
print(list(map(lambda x: x+5,alist)))


names = ['microsoft','oracle','google','ibm']
#Output: ["www.microsoft.com","www.oracle.com","www.google.com","www.ibm.com"]



data = {'a': 5, 'b': 10, 'c': 15}
result = dict(map(lambda item: (item[0], item[1] + 10), data.items()))
print(result)


## filter(function,iterable)
alist = [1,2,3,4,5,6]

output = list(filter(lambda x:x%2==0,alist))
print(output)

data = ["unix","java","python","c","perl"]
output = list(filter(lambda x:len(x)==4,data))
print(output)