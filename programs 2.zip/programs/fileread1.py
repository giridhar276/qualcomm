

import csv
#windows: with open(".\\csvfiles\\adult.csv","r") as fobj:
#linux:  with open("./csvfiles/adult.csv","r") as fobj:
with open("./csvfiles/adult.csv","r") as fobj:
    data = csv.reader(fobj)
    for line in data:
        print(line[1])
        print(line[3])


'''
write a program to read adult.csv and display the below output:

Total Male count :  3434
Total Female count:  34

'''

