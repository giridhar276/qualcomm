


def displayoutput():
    for val in [range(1,1000)]:
        print(val)
displayoutput()



## generator : if the block or definition contains yield keyword .. we call it generator

# advantage:   memory is efficiently used, lazy evaluation
# using generator
def getvalues():
    for val in range(1,1000):
        yield val

def displayvalues():
    for val in getvalues():
        print(val)

displayvalues()