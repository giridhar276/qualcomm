

# raise - if you want to raise the exception wantedly then we use raise keyword


name = "python"
if not name.isupper():
    #raise("String is uppercase")
    raise(Exception)