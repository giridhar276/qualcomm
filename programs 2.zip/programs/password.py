
username = input("Enter any username :")
password = input("Enter password :")