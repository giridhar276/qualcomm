


fobj = open("customers.txt","w")
fobj.write("tcs\n")
fobj.close()



# writing numbers to the file
fobj = open("numbers.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")
fobj.close()


# context manager
# If line starts using with keyword, we call it context manager
# file gets closed automatically 
with open("customers.txt","w") as fobj:
    fobj.write("tcs\n")






