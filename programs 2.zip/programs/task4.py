'''
write a program to display the below information

1) current working directory  
2) login name
3) current process id
4) current python version
5) all the libraries available in python
6) all the environment variables
7) operating system name
8) platform name
9)current date and time
10)statistics of adult.csv file
11)create empty file with today's timestamp
'''

import os
import sys
import platform
import datetime
import time
print(os.getcwd())
print(os.getlogin())
print(os.getpid())
print(sys.version)
print(sys.version_info)
print(os.environ)
print(os.name)
print(platform.uname())
print(platform.platform())
print(datetime.datetime.now())
print(datetime.date.today())

print(os.stat("adult.csv"))


filename = time.strftime("%d_%b_%Y.csv")
print(type(filename))

with open(filename,"w") as fobj:
    pass