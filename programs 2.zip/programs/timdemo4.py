import timeit
# Setup code
setup = '''
import random
random_list = [random.randint(1, 100) for _ in range(1000)]
'''

# List comprehension
list_comp = '''
squares = [x**2 for x in random_list]
'''

# For loop
for_loop = '''
squares = []
for x in random_list:
    squares.append(x**2)
'''

# Timing
time_list_comp = timeit.timeit(list_comp, setup=setup, number=1000)
time_for_loop = timeit.timeit(for_loop, setup=setup, number=1000)

print(f'List comprehension time: {time_list_comp} seconds')
print(f'For loop time: {time_for_loop} seconds')