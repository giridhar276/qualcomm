
info = {
  "products": [
    {
      "id": 1001,
      "name": "Laptop",
      "price": 999.99,
      "specs": {
        "cpu": "Intel i7",
        "ram": "16GB",
        "storage": "512GB SSD"
      }
    },
    {
      "id": 1002,
      "name": "Smartphone",
      "price": 699.99,
      "specs": {
        "cpu": "Snapdragon 888",
        "ram": "8GB",
        "storage": "256GB"
      }
    },
    {
      "id": 1003,
      "name": "laptop",
      "price": 699.99,
      "specs": {
        "cpu": "Snapdragon 888",
        "ram": "8GB",
        "storage": "256GB"
      }
    }

  ],
  "store": {
    "name": "Tech Store",
    "location": "San Francisco",
    "contact": {
      "email": "support@techstore.com",
      "phone": "+1-800-555-1234"
    }
  }
}

#1001,laptop
#1002,smartphone
#1003,laptop