

atup = (30,40,2,45,32,34)
print(atup)

# comment this line
atup[0] = 300
print("After modifying:",atup)   #invalid line   # tuple is immutable


print(atup.count(30))

print(atup.index(34))