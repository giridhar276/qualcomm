book  = { "chap1":10 ,"chap2":20 ,"chap3":30 }
print(book)
print(book['chap1'])
# display keys
print(book.keys())
# display values
print(book.values())
# display key-value as item
print(book.items())

book.pop("chap1")
print("After pop operation :",book)

book.popitem()  # remove the last key-value
print(book)
newbook = {"chap4":40,"chap5":50}
book.update(newbook)
print("updated dictionary",book)

# add new key-value
book["chap1"] = 10
book["chap2"] = 20
book["chap8"] = 80
print(book)
