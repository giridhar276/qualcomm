

ip = "192.168.{}.{}"
for val in range(0,2):
    for ival in range(1,11):
        print(ip.format(val,ival))
