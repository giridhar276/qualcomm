
import cProfile


def set_of_values():
    total = 0
    for val in range(1,1000000000):
        total+=1
    return total

#print(set_of_values())

cProfile.run("set_of_values()")