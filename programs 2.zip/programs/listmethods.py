alist = [10,20,30,45,32,5,4,56]
print(alist)
#slicing
print(alist[0:5])
print(alist[::-1])

#list methods
alist.append(56)
alist.append(90)
print("After appending:",alist)

#list.extend(list)
alist.extend([20,40,13])
print(alist)

#list.insert(index,value)
alist.insert(4,400)
alist.insert(1,100)
print("After inserting:",alist)

print(alist.count(10))

#list.sort()
alist.sort()
print(alist)

#list.reverve()
alist.reverse()
print(alist)