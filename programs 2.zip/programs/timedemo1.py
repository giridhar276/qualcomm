

from timeit import Timer

def demo():
    output = sum(range(100))

t = Timer(demo)

time_taken = t.timeit(number = 1000)
print("time taken :", time_taken)