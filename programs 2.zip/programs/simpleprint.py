print("python programming")

print('java programming')

print("""machine learning""")