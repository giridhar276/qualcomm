name = "python"
# simple if
if name.isupper():
    print("string is upper")
    print("inside if")

# if-else
if name.isupper():
    print("string is upper")
    print("inside if")
else:
    print("string is lower")

#if-elif-elif-elif-elif-else
if name.isupper():
    print("string is upper")
elif name.islower():
    print("String is lower")
elif name.isalpha():
    print("string has only alphas")
else:
    print("Not an string")

alist = [10,20,30]
if 10 in alist:
    print("10 exists..")

name = "python programming"
if "ram" in name:
    print("exists")

book = {"chap1":10 , "chap2":20}
if "chap1" in book:
    print("key exists...")
