# reading the file line by line using file object
with open("customers.txt","r") as fobj:
    for line in fobj:
        print(line.strip())

# using fobj.readlines()   ----> output in list
with open("customers.txt","r") as fobj:
    print(fobj.readlines())

# using fobj.read()        -----> output in string
with open("customers.txt","r") as fobj:
    print(fobj.read())
    print(type(fobj.read()))

# using csv library
import csv
with open("customers.txt","r") as fobj:
    # converting to csv object
    data = csv.reader(fobj)
    for line in data:
        print(line)  # each line gets converted to list

# execute the below command before executing the code
# pip install pandas 
# using pandas library
import pandas
df = pandas.read_csv("customers.txt")
print(df)