# fixed arguments
def display(a,b):
    c = a + b
    return c
total = display(10,20)
print(total)

# default arguments
def displayValues(a = 0,b = 0,c = 0,d = 0):
    print(a,b,c,d)
displayValues(10)
displayValues(10,20)
displayValues(10,20,30)
displayValues(10,20,30,40)

# keyword arguments
def displayData(c,a,b):
    print(a,b,c)
displayData(a=10,b = 20,c = 30)


# variable length arguments
# *object is a tuple
def displayValues(*args):
    for val in args:
        print(val)
displayValues(10,20,30,34,56,32,56,23,87,65,43,21,43,65,78,25,37,45,43,56,67,43,67,45,34,"unix")


def displayData(**kwargs):
    #print(kwargs)
    for key,value in kwargs.items():
        print(key,value)
displayData(chap1=10,chap2=20)








