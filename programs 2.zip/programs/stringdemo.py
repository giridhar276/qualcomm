import pdb
pdb.set_trace()  # beginning point
name = "python programming"
print(name)
print("I love",name)

# slicing
#string[start:stop:step]
print(name[0:5])
print(name[4:9])
print(name[4])
print(name[-1])
print(name[-4])
print(name[0:17:2])
print(name[1:17:5])
print(name[-5:-3])
print(name[::])  #python programming   #start = 0  stop=18  step = 1
print(name[:])   #python programming
print(name[::-1])  # will display the string in reverse order ( step value is -ve)

first = "python"
second = "programing"
final = first + " " + second    # + is used for concatenating
print(final)

print(final * 5)     # * is used ffor repetitive operator

print(name)
print(name.capitalize())
print(name.title())
print(name.count('p'))
print(name.count("w"))
print(len(name))
print(name.startswith("p"))
print(name.startswith("w"))
print(name.endswith("g"))
print(name.isalpha())
print(name.isalnum())
print(name.isupper())
print(name.islower())
print(name.split(" "))
#pdb.set_trace()
print(name.replace("python","r"))
print(name)   # we are not modifying the original string ... string is immutable

